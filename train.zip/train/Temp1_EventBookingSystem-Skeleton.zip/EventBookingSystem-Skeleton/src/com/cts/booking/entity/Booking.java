package com.cts.booking.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

public class Booking {

	private int custId;
	
	private int eventId;
	
//create custId and eventId as composite primary keys and change the class structure accordingly
	
	private int ticketsBooked;
	
	private float amount;


}
